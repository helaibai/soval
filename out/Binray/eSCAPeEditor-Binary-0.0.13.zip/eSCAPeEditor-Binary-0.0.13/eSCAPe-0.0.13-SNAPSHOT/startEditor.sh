#!/bin/sh
# javaw must be in the path, e.g c:\java\bin
javaw -Xmx256m -jar eSCAPe-0.0.13-SNAPSHOT.jar $* &
