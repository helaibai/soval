package com.g2inc.scap.library.domain.xccdf;

public interface SelectorAbstract {
	
	public String getSelector();
	public void setSelector(String selector);

}
