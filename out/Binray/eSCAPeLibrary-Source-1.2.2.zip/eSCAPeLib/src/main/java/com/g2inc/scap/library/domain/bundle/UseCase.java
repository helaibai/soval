package com.g2inc.scap.library.domain.bundle;

public enum UseCase {
	VULNERABILITY_XCCDF_OVAL,CONFIGURATION,SYSTEM_INVENTORY,VULNERABILITY_OVAL;
}
