package com.g2inc.scap.library.domain.ocil;

import com.g2inc.scap.model.ocil.StringQuestionResult;

public class StringQuestionResultImpl extends QuestionResultImpl implements StringQuestionResult {

	@Override
	public String getAnswer() {
		return element.getAttributeValue("answer");
	}

	@Override
	public void setAnswer(String answer) {
		element.setAttribute("answer", answer);
	}

}
