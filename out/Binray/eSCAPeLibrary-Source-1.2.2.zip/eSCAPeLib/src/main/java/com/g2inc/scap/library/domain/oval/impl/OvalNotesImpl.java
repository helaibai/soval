package com.g2inc.scap.library.domain.oval.impl;

import com.g2inc.scap.library.domain.oval.OvalNotes;
import com.g2inc.scap.library.domain.oval.OvalDefinitionsDocument;

public class OvalNotesImpl extends OvalNotes
{
	public OvalNotesImpl(OvalDefinitionsDocument parentDocument)
	{
		super(parentDocument);
	}
}
