package com.g2inc.scap.library.domain.ocil.impl.OCIL2;

import org.jdom.Document;

import com.g2inc.scap.library.domain.SCAPDocumentTypeEnum;

public class OcilDocument extends com.g2inc.scap.library.domain.ocil.OcilDocumentImpl {
	
	public OcilDocument(Document document) {
		super(document); 
        setDocumentType(SCAPDocumentTypeEnum.OCIL_2);
	}
	
	@Override
	public String getSchemaVersion() {
		return "2.0";
	}

}
