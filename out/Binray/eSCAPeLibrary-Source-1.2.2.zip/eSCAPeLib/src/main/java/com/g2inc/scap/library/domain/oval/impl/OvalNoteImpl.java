package com.g2inc.scap.library.domain.oval.impl;

import com.g2inc.scap.library.domain.oval.OvalNote;
import com.g2inc.scap.library.domain.oval.OvalDefinitionsDocument;

public class OvalNoteImpl extends OvalNote
{
	public OvalNoteImpl(OvalDefinitionsDocument parentDocument)
	{
		super(parentDocument);
	}
}
