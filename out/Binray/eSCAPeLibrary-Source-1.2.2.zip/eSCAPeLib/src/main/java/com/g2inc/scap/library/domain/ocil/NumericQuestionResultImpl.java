package com.g2inc.scap.library.domain.ocil;

import java.math.BigDecimal;

import com.g2inc.scap.model.ocil.NumericQuestionResult;

public class NumericQuestionResultImpl extends QuestionResultImpl implements NumericQuestionResult {

	@Override
	public BigDecimal getAnswer() {
		return getBigDecimalAttribute("answer");
	}

	@Override
	public void setAnswer(BigDecimal answer) {
		setBigDecimalAttribute("answer", answer);
	}

}
