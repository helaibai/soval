package com.g2inc.scap.library.domain.ocil;

import com.g2inc.scap.model.ocil.BooleanQuestionResult;

public class BooleanQuestionResultImpl extends QuestionResultImpl implements BooleanQuestionResult {

	@Override
	public Boolean getAnswer() {
		return getBoolean("answer");
	}

	@Override
	public void setAnswer(Boolean answer) {
		setBoolean("answer", answer);
	}

}
