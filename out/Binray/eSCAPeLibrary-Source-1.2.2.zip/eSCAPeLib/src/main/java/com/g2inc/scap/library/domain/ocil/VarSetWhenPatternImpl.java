package com.g2inc.scap.library.domain.ocil;

import com.g2inc.scap.model.ocil.VarSetWhenPattern;

public class VarSetWhenPatternImpl extends VarSetWhenConditionImpl implements VarSetWhenPattern {
	
	@Override
	public String getPattern() {		
		return element.getText();		
	}
	
	@Override
	public void setPattern(String pattern) {
		element.setText(pattern);
	}

}
