package com.g2inc.scap.library.domain.ocil;

import com.g2inc.scap.model.ocil.ChoiceGroupRef;

public class ChoiceGroupRefImpl extends ModelBaseImpl implements ChoiceGroupRef {

	@Override
	public String getRefId() {
		return element.getText();
	}

	@Override
	public void setRefId(String refId) {
		element.setText(refId);
	}
	

}
