package com.g2inc.scap.library.domain.xccdf;


public interface SelComplexValueElement extends SelValueElement, ComplexValueElement {
	
}
